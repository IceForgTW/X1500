#ifndef __SC_DEBUG_H__
#define __SC_DEBUG_H__

#ifdef __cplusplus
extern"C" {
#endif
/************************************************************************/
#define SC_DEBUG_BUF_LEN        64
#define SC_PRINTF               //SC_Debug


extern void SC_Debug(char* Format,...);

/************************************************************************/
#ifdef __cplusplus
}
#endif
#endif //__SC_DEBUG_H__

